#include<stdio.h>
main()
{
	int a;
	for(a=1;a<=20;a++);
	printf("\n %d",a);
	
}
