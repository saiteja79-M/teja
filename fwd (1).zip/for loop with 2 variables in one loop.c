#include<stdio.h>
main()
{
	int a,b;
	for(a=1,b=20;a<=20,b>=1;a++,b--)
	{
	printf("\n %d \t %d",a,b);
	}
}